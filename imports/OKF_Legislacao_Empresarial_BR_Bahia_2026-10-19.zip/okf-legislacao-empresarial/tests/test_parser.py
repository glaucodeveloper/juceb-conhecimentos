import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from sync_official import split_articles,decode_html,normalize

def test_article_segmentation():
    legal='Art. 1º A norma trata de efeitos de teste com detalhes suficientes.\n§ 1º Segue parágrafo.\nArt. 2º Este dispositivo também possui texto considerável.'
    got=split_articles(legal)
    assert len(got)==2, got
    assert got[0]['article']=='1' and got[1]['article']=='2'
    assert '§ 1º' in got[0]['raw']

def test_utf8_extraction():
    txt=decode_html('<html><body><p>Aplicação jurídica válida</p></body></html>'.encode('utf-8'))
    assert 'Aplicação jurídica válida' in txt

if __name__=='__main__':
    test_article_segmentation()
    test_utf8_extraction()
    print('Testes locais OK')
