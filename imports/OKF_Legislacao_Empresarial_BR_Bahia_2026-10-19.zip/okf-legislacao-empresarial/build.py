#!/usr/bin/env python3
"""Build offline OKF discovery records from a curated legal source registry.
Records are bibliographic seeds, NOT official full-text reproductions.
"""
import json, pathlib, hashlib, re, datetime, collections, csv
ROOT=pathlib.Path(__file__).resolve().parent
DATE='2026-10-19'
L=[]
def add(domain,kind,num,year,title,url,subjects='',links='',source='Planalto',verified=False,notes=''):
    slug=f'{kind.lower().replace(" ","-")}-{str(num).replace("/","-")}-{year}'
    slug=re.sub('[^a-z0-9-]+','-',slug.lower()).strip('-')
    id=f'BR.{kind.upper().replace(" ","_")}.{num}.{year}' if domain!='07_bahia' else f'BR.BA.{kind.upper().replace(" ","_")}.{num}.{year}'
    L.append(dict(id=id,slug=slug,domain=domain,kind=kind,number=str(num),year=year,title=title,official_url=url,subjects=[x.strip() for x in subjects.split(';') if x.strip()],links=[x.strip() for x in links.split(';') if x.strip()],authority=source,source_verified=verified,notes=notes))
P='https://www.planalto.gov.br/ccivil_03/'
# BASE GERAL
add('00_fundamentos','Constituição','1988',1988,'Constituição Federal (texto compilado)',P+'constituicao/constituicaocompilado.htm','competencias tributarias;direitos fundamentais;ordem economica',verified=True)
add('00_fundamentos','Lei','5172',1966,'Código Tributário Nacional',P+'leis/l5172compilado.htm','tributos;obrigacao tributaria;credito tributario;prescricao',verified=False)
add('00_fundamentos','Lei','13105',2015,'Código de Processo Civil',P+'_ato2015-2018/2015/lei/l13105.htm','processo judicial;execucao',verified=False)
add('00_fundamentos','Lei','9784',1999,'Processo administrativo federal',P+'leis/l9784.htm','processo administrativo',verified=False)
add('00_fundamentos','Lei','12016',2009,'Mandado de segurança',P+'_ato2007-2010/2009/lei/l12016.htm','contencioso;direitos',verified=False)
add('01_registro','Lei','8934',1994,'Registro Público de Empresas Mercantis',P+'leis/l8934compilado.htm','junta comercial;registro;atos;arquivamento',verified=True)
add('01_registro','Decreto','1800',1996,'Regulamenta o Registro Público de Empresas',P+'decreto/d1800.htm','junta comercial;sinrem;registro',verified=True)
add('01_registro','Lei','10406',2002,'Código Civil',P+'leis/2002/l10406compilada.htm','sociedade limitada;empresario individual;contratos',verified=True)
add('01_registro','Lei','6404',1976,'Lei das Sociedades por Ações',P+'leis/l6404consol.htm','sociedade anonima;fusao;incorporacao;cisao',verified=False)
add('01_registro','Lei','5764',1971,'Lei das Cooperativas',P+'leis/l5764.htm','cooperativa;registro',verified=False)
add('01_registro','Lei','11598',2007,'REDESIM',P+'_ato2007-2010/2007/lei/l11598.htm','redesim;abertura;legalizacao;licenciamento',verified=True)
add('01_registro','Lei','13874',2019,'Declaração de Direitos de Liberdade Econômica',P+'_ato2019-2022/2019/lei/l13874.htm','licenciamento;baixo risco;liberdade economica',verified=True)
add('01_registro','Lei','14195',2021,'Ambiente de Negócios',P+'_ato2019-2022/2021/lei/l14195.htm','registro empresarial;facilitacao;proteção investidores',verified=False)
add('01_registro','Lei','11101',2005,'Recuperação Judicial e Falência',P+'_ato2004-2006/2005/lei/l11101.htm','recuperacao;falencia',verified=False)
add('01_registro','Lei','12529',2011,'Sistema Brasileiro de Defesa da Concorrência',P+'_ato2011-2014/2011/lei/l12529.htm','concorrencia;fusao',verified=False)
add('01_registro','IN DREI','81',2020,'Normas gerais de registro e manuais', 'https://www.gov.br/empresas-e-negocios/pt-br/drei/legislacao/instrucoes-normativas/arquivos-instrucoes-normativas-em-vigor/INDREI81_Atualizada_in0125.pdf/@@display-file/file','registro;atos;empresario individual;sociedade limitada;cooperativa',source='DREI',verified=True,notes='Catálogo inclui versões atualizadas e anexos; coletor faz descoberta de links dos manuais.')
add('01_registro','IN DREI','82',2021,'Autenticação de livros empresariais','https://www.gov.br/empresas-e-negocios/pt-br/drei/legislacao/arquivos/legislacoes-federais/indrei822023_compilada.pdf/@@display-file/file','livros;escrituracao',source='DREI',verified=True,notes='Página índice: localizar arquivo da IN 82.')
add('01_registro','Manual DREI','anexoII',2025,'Manual de Registro de Empresário Individual — IN DREI 81/2020','https://www.gov.br/empresas-e-negocios/pt-br/drei/legislacao/instrucoes-normativas/arquivos-instrucoes-normativas-em-vigor/anexo-ii-empresario-individual_link.pdf/@@display-file/file','empresario individual;registro;constituicao;alteracao;extincao',source='DREI',verified=True,notes='Versão do anexo referida no índice oficial; contém histórico e link à versão compilada.')
add('01_registro','Manual DREI','anexoIV',2025,'Manual de Registro de Sociedade Limitada — IN DREI 81/2020','https://www.gov.br/empresas-e-negocios/pt-br/drei/legislacao/instrucoes-normativas/arquivos-instrucoes-normativas-em-vigor/anexo-iv-limitada_link.pdf/@@display-file/file','sociedade limitada;contrato social;registro;alteracao;extincao',source='DREI',verified=True,notes='Conferir versão compilada linkada no PDF.')
add('01_registro','Manual DREI','anexoV',2025,'Manual de Registro de Sociedade Anônima — IN DREI 81/2020','https://www.gov.br/empresas-e-negocios/pt-br/drei/legislacao/instrucoes-normativas/arquivos-instrucoes-normativas-em-vigor/anexo-v-sa_link.pdf/@@display-file/file','sociedade anonima;registro;ata',source='DREI',verified=True)
add('01_registro','Manual DREI','anexoVI',2025,'Manual de Registro de Cooperativa — IN DREI 81/2020','https://www.gov.br/empresas-e-negocios/pt-br/drei/legislacao/instrucoes-normativas/arquivos-instrucoes-normativas-em-vigor/anexo-vi-cooperativa_link.pdf/@@display-file/file','cooperativa;registro;atos societarios',source='DREI',verified=True)
add('01_registro','IN DREI','1',2025,'Altera IN DREI 81/2020','https://www.gov.br/empresas-e-negocios/pt-br/drei/legislacao/instrucoes-normativas','registro;atualizacoes',source='DREI',verified=True,notes='Pág. índice. Vigência e alterações devem ser verificadas no ato.')
add('01_registro','Portal JUCEB','legislacao',2026,'Legislação indexada pela Junta Comercial da Bahia','https://www.ba.gov.br/juceb/legislacao/leis','juceb;normas empresariais',source='JUCEB',verified=True,notes='Página índice, não ato normativo isolado.')
add('01_registro','Portal JUCEB','resolucoes',2026,'Resoluções do Plenário JUCEB','https://www.ba.gov.br/juceb/editais/12622/resolucoes-do-plenario-2','juceb;resolucoes;procedimentos',source='JUCEB',verified=True,notes='Contém resoluções 2025/2026; descobrir PDFs individualmente.')
# SIMPLES
add('02_simples','LC','123',2006,'Estatuto ME/EPP e Simples Nacional',P+'leis/lcp/lcp123.htm','simples nacional;mei;me;epp;anexos;fator r;vedacoes;sublimites;das',verified=True)
add('02_simples','LC','128',2008,'Institui regulamentações relativas ao MEI',P+'_ato2007-2010/2008/lei/lcp128.htm','mei;microempreendedor',verified=False)
add('02_simples','LC','147',2014,'Alterações do Simples Nacional',P+'_ato2011-2014/2014/lei/lcp147.htm','simples nacional;enquadramento',verified=False)
add('02_simples','LC','155',2016,'Reestruturação da apuração do Simples Nacional',P+'leis/lcp/lcp155.htm','simples nacional;anexos;aliquota efetiva',verified=True)
add('02_simples','LC','167',2019,'Empresa Simples de Crédito e Inova Simples',P+'leis/lcp/lcp167.htm','simples nacional;inova simples',verified=False)
add('02_simples','Resolução CGSN','140',2018,'Regulamento geral do Simples Nacional','https://normas.receita.fazenda.gov.br/sijut2consulta/consulta/normas.fazenda.gov.br/sijut2consulta/link.action?idAto=92278&visao=original','simples nacional;pgdas;defis;opcao;anexos;fator r;escrituracao',source='Receita Federal (SIJUT)',verified=True,notes='Ato multivigente: coletar versao compilada por instrumento do SIJUT; nao assumir original como vigente.')
add('02_simples','Resolução CGSN','187',2026,'Alterações CGSN 140/2018 (abril 2026)','https://normas.receita.fazenda.gov.br/sijut2consulta/consulta/normas.fazenda.gov.br/sijut2consulta/link.action?idAto=92278&visao=original','simples nacional;alteracoes',source='Receita Federal (SIJUT)',verified=True,notes='Link para histórico do ato 140, não para texto isolado 187.')
add('02_simples','Resolução CGSN','190',2026,'Alterações CGSN 140/2018 (agosto 2026)','https://normas.receita.fazenda.gov.br/sijut2consulta/consulta/normas.fazenda.gov.br/sijut2consulta/link.action?idAto=92278&visao=original','simples nacional;tributacao reforma;transicao',source='Receita Federal (SIJUT)',verified=True,notes='Link para histórico do ato 140; alterações com produção futura de efeitos.')
add('02_simples','Resolução CGSN','191',2026,'Alterações CGSN 140/2018 (agosto 2026)','https://normas.receita.fazenda.gov.br/sijut2consulta/consulta/normas.fazenda.gov.br/sijut2consulta/link.action?idAto=92278&visao=original','simples nacional;regime caixa',source='Receita Federal (SIJUT)',verified=True,notes='Link para histórico do ato 140; verificar datas de produção de efeitos.')
add('02_simples','Portal Receita','simples',2026,'Orientações tributárias do Simples Nacional','https://www8.receita.fazenda.gov.br/SimplesNacional/','simples nacional;pgdas;manuais',source='Receita Federal',verified=False,notes='Portal de serviços e manuais, não diploma legal.')
# ICMS, ISS, tributos federais
add('03_tributos','LC','87',1996,'Lei Kandir — ICMS',P+'leis/lcp/lcp87.htm','icms;circulacao;credito;nao incidencia;difal',verified=True)
add('03_tributos','LC','190',2022,'ICMS diferencial de alíquotas (DIFAL)',P+'leis/lcp/lcp190.htm','icms;difal;consumidor final',verified=True)
add('03_tributos','LC','192',2022,'Regime monofásico do ICMS sobre combustíveis',P+'leis/lcp/lcp192.htm','icms;combustiveis;monofasico',verified=False)
add('03_tributos','LC','116',2003,'ISS e lista de serviços',P+'leis/lcp/lcp116.htm','iss;servicos;lista servicos;local incidencia',verified=True)
add('03_tributos','LC','157',2016,'Alterações da legislação do ISS',P+'leis/lcp/lcp157.htm','iss;aliquota minima',verified=False)
add('03_tributos','LC','175',2020,'ISS de serviços determinados e obrigações acessórias',P+'leis/lcp/lcp175.htm','iss;servicos;local incidencia',verified=False)
add('03_tributos','Decreto','7212',2010,'Regulamento do IPI',P+'_ato2007-2010/2010/decreto/d7212.htm','ipi;industrializacao;estabelecimento industrial',verified=False)
add('03_tributos','Decreto','11158',2022,'TIPI — Tabela de Incidência do IPI',P+'_ato2019-2022/2022/decreto/d11158.htm','ipi;tipi;ncm',verified=False)
add('03_tributos','Lei','9718',1998,'PIS/Pasep e Cofins; legislação geral',P+'leis/l9718.htm','pis;cofins;cumulativo',verified=False)
add('03_tributos','Lei','10637',2002,'PIS/Pasep — não cumulatividade',P+'leis/2002/l10637compilado.htm','pis;creditos;nao cumulatividade',verified=True)
add('03_tributos','Lei','10833',2003,'Cofins — não cumulatividade',P+'leis/2003/l10.833compilado.htm','cofins;creditos;nao cumulatividade',verified=True,notes='Versão compilada confirmada no Planalto.')
add('03_tributos','Lei','10865',2004,'PIS/Cofins Importação',P+'_ato2004-2006/2004/lei/l10.865.htm','pis;cofins;importacao',verified=False)
add('03_tributos','Decreto','9580',2018,'Regulamento do Imposto sobre a Renda',P+'_ato2015-2018/2018/decreto/d9580.htm','irpj;irpf;lucro real;lucro presumido',verified=False)
add('03_tributos','Lei','7689',1988,'Contribuição Social sobre o Lucro Líquido',P+'leis/l7689.htm','csll;lucro',verified=False)
add('03_tributos','Lei','9249',1995,'IRPJ e CSLL - disposições gerais',P+'leis/l9249.htm','irpj;csll;lucro presumido',verified=False)
add('03_tributos','Lei','9430',1996,'Legislação tributária federal e fiscalização',P+'leis/l9430.htm','irpj;tributos federais;fiscalizacao',verified=False)
add('03_tributos','Lei','8981',1995,'Imposto de Renda e legislação correlata',P+'leis/l8981.htm','irpj;retencoes',verified=False)
add('03_tributos','Decreto','6306',2007,'Regulamento do IOF',P+'_ato2007-2010/2007/decreto/d6306.htm','iof;credito;cambio;seguro',verified=False)
add('03_tributos','Decreto Lei','37',1966,'Imposto de Importação e normas aduaneiras',P+'decreto-lei/del0037.htm','importacao;tributos aduaneiros',verified=False)
add('03_tributos','Decreto','6759',2009,'Regulamento Aduaneiro',P+'_ato2007-2010/2009/decreto/d6759.htm','importacao;exportacao;aduana',verified=False)
add('03_tributos','Lei','8212',1991,'Custeio da Seguridade Social',P+'leis/l8212cons.htm','contribuicoes previdenciarias;cpp;folha',verified=False)
add('03_tributos','Lei','8213',1991,'Planos de Benefícios da Previdência Social',P+'leis/l8213cons.htm','previdencia;trabalhista',verified=False)
add('03_tributos','Decreto Lei','5452',1943,'Consolidação das Leis do Trabalho',P+'decreto-lei/del5452.htm','clt;trabalhista;folha',verified=False)
add('03_tributos','Lei','8036',1990,'FGTS',P+'leis/l8036consol.htm','fgts;trabalho',verified=False)
# Fiscal e documentos
add('04_obrigacoes','Decreto','6022',2007,'SPED — Sistema Público de Escrituração Digital',P+'_ato2007-2010/2007/decreto/d6022.htm','sped;escrituracao digital',verified=False)
add('04_obrigacoes','Decreto','8373',2014,'eSocial',P+'_ato2011-2014/2014/decreto/d8373.htm','esocial;folha;obrigacoes',verified=False)
add('04_obrigacoes','IN RFB','2005',2021,'DCTFWeb (verificar alterações e atos substitutos)','https://normas.receita.fazenda.gov.br/sijut2consulta/consulta.action','dctfweb;previdencia;tributos',source='Receita Federal',verified=False,notes='Página genérica: localizar ato exato no SIJUT antes de importar.')
add('04_obrigacoes','IN RFB','2110',2022,'Normas gerais de tributação previdenciária','https://normas.receita.fazenda.gov.br/sijut2consulta/consulta.action','contribuicoes previdenciarias;folha',source='Receita Federal',verified=False,notes='Página genérica: localizar ato exato no SIJUT antes de importar.')
add('04_obrigacoes','Portal ENCAT','nfe',2026,'NF-e, NFC-e, CT-e, MDF-e — notas técnicas e esquemas','https://www.nfe.fazenda.gov.br/portal/principal.aspx','nfe;nfce;documentos fiscais',source='SEFAZ/ENCAT',verified=False,notes='Documentos técnicos mudam: selecionar pacote e NT exatos na ingestão.')
add('04_obrigacoes','Portal NFS-e','nacional',2026,'Padrão Nacional NFS-e e documentação','https://www.gov.br/nfse/pt-br','nfse;documentos fiscais;iss',source='Comitê Gestor NFS-e',verified=False)
# REFORMA
add('05_reforma','EC','132',2023,'Reforma Tributária do Consumo',P+'constituicao/emendas/emc/emc132.htm','ibs;cbs;is;transicao',verified=True)
add('05_reforma','LC','214',2025,'IBS, CBS, Imposto Seletivo e legislação do consumo',P+'leis/lcp/lcp214compilado.htm','ibs;cbs;is;creditos;regimes diferenciados;transicao',verified=True)
add('05_reforma','LC','227',2026,'CGIBS e processo administrativo do IBS',P+'leis/lcp/lcp227.htm','ibs;cgibs;processo administrativo;alteracoes simples',verified=True)
add('05_reforma','Decreto','12955',2026,'Regulamentação da LC 214/2025',P+'_ato2023-2026/2026/decreto/d12955.htm','ibs;cbs;reforma',verified=False)
add('05_reforma','LC','229',2026,'Benefícios tributários e despesas de 2026',P+'leis/lcp/lcp229.htm','tributos;beneficios',verified=True)
add('05_reforma','LC','228',2026,'PIS/Cofins na indústria química',P+'leis/lcp/lcp228.htm','pis;cofins;industria',verified=True)
# Bahia: fontes confirmadas
add('07_bahia','Lei BA','7014',1996,'ICMS da Bahia — Lei 7.014/1996','https://mbusca.sefaz.ba.gov.br/DITRI/leis/leis_estaduais/legest_1996_7014_icmscomnotas.pdf','icms bahia;fato gerador;aliquota;creditos',source='SEFAZ-BA',verified=True,notes='PDF compilado informativo; fonte autêntica é Diário Oficial; versão de compilação observada inclui alterações até Lei 14.971/2024.')
add('07_bahia','Decreto BA','13780',2012,'Regulamento ICMS da Bahia (RICMS-BA)','https://mbusca.sefaz.ba.gov.br/DITRI/normas_complementares/decretos/decreto_2012_13780_ricms_texto_2021.pdf','icms bahia;cad icms;substituicao tributaria;notas fiscais',source='SEFAZ-BA',verified=True,notes='PDF compilado informativo, capa observada com atualização até Decreto 24.829/2026; verificar data de acesso e publicação.')
add('07_bahia','Anexo RICMS BA','1',2026,'Anexo I RICMS-BA — Substituição Tributária','https://mbusca.sefaz.ba.gov.br/DITRI/normas_complementares/decretos/decreto_2012_13780_ricms_anexo_1_vigente_2026.pdf','icms bahia;ncm;cest;st;mv a',source='SEFAZ-BA',verified=True)
add('07_bahia','Portal SEFAZ BA','normas',2026,'Acompanhamento de normas e portarias tributárias da Bahia','https://www.sefaz.ba.gov.br/','icms bahia;portarias;decretos',source='SEFAZ-BA',verified=True,notes='Portal raiz: descoberta complementar de atos aplicáveis.')
add('07_bahia','Portal JUCEB','drei',2026,'Instruções normativas DREI reconhecidas pela JUCEB','https://www.ba.gov.br/juceb/legislacao/instrucoes-normativas-drei','juceb;drei;registro',source='JUCEB',verified=True)
add('07_bahia','Portal JUCEB','procedimentos',2026,'Passo a passo de registro na JUCEB','https://www.ba.gov.br/juceb/passo-passo','juceb;atos;viabilidade;registro',source='JUCEB',verified=True)
# Complements relevant to all companies in the two areas
add('08_transversal','Lei','8078',1990,'Código de Defesa do Consumidor',P+'leis/l8078compilado.htm','consumidor;servicos;mercadorias',verified=False)
add('08_transversal','Lei','13709',2018,'LGPD — proteção de dados pessoais',P+'_ato2015-2018/2018/lei/l13709.htm','lgpd;tratamento dados;empresa',verified=False)
add('08_transversal','Lei','12965',2014,'Marco Civil da Internet',P+'_ato2011-2014/2014/lei/l12965.htm','internet;prestador;dados',verified=False)
add('08_transversal','Lei','9605',1998,'Crimes Ambientais',P+'leis/l9605.htm','meio ambiente;licenciamento',verified=False)
add('08_transversal','LC','140',2011,'Competências ambientais e licenciamento',P+'leis/lcp/lcp140.htm','licenciamento ambiental;competencias',verified=False)
add('08_transversal','Lei','12305',2010,'Política Nacional de Resíduos Sólidos',P+'_ato2007-2010/2010/lei/l12305.htm','residuos;industria;comercio',verified=False)
add('08_transversal','Lei','14133',2021,'Nova Lei de Licitações e Contratos Administrativos',P+'_ato2019-2022/2021/lei/l14133.htm','licitacoes;vendas governo;servicos',verified=False)
add('08_transversal','Lei','12187',2009,'Política Nacional sobre Mudança do Clima',P+'_ato2007-2010/2009/lei/l12187.htm','industria;ambiental',verified=False)
add('08_transversal','Lei','10192',2001,'Normas sobre medidas complementares ao Plano Real',P+'leis/leis_2001/l10192.htm','contratos;precos',verified=False)
add('08_transversal','Lei','10741',2003,'Estatuto da Pessoa Idosa',P+'leis/2003/l10.741.htm','atendimento;consumidor',verified=False)
# Structural crosswalk references and deliberate exclusions
TAXONOMY={
'02_simples':['mei','simei','me','epp','vedacoes','anexos I-V','fator R','PGDAS-D','DEFIS','DAS','sublimites ICMS/ISS','regime caixa/competencia','segregacao receitas'],
'03_tributos':['icms','iss','ipi','pis','cofins','irpj','csll','cpp','iof','importacao','exportacao','retencoes'],
'04_obrigacoes':['nfe','nfce','nfse','cte','mdfe','sped efd','ecd','ecf','esocial','reinf','dctfweb'],
'05_reforma':['ibs','cbs','imposto seletivo','creditos','simples nacional','transicao 2026-2033'],
'07_bahia':['juceb','cad-icms','substituicao tributaria','difal','municipios/iss','licencas']}

def dumps(obj):return json.dumps(obj,ensure_ascii=False,indent=2)+'\n'
for entry in L:
    parent=ROOT/'okf'/entry['domain']; parent.mkdir(parents=True,exist_ok=True)
    source=dict(id=entry['id'],tipo=entry['kind'],numero=entry['number'],ano=entry['year'],jurisdicao='BA' if entry['domain']=='07_bahia' else 'BR',orgao=entry['authority'],url=entry['official_url'],verificacao_url='consulta_dirigida' if entry['source_verified'] else 'pendente',consultado_em=DATE if entry['source_verified'] else None,texto_integral_capturado=False,hash_sha256=None)
    record={'schema':'okf.knowledge.v1','id':entry['id'],'title':entry['title'],'summary':f"Referência normativa no domínio {entry['domain']}; sem transcrição integral no arquivo de descoberta. Texto obtido posteriormente por sync_official.py.",
        'elements':[{'id':'norma:'+entry['id'],'type':'ato_normativo','name':entry['title'],'attributes':{'kind':entry['kind'],'year':entry['year'],'jurisdiction':source['jurisdicao'],'subjects':entry['subjects']}}],
        'properties':[{'name':'fonte_primaria_obrigatoria','value':True},{'name':'proibido_inferir_vigencia_sem_conferencia','value':True}],
        'relations':[{'type':'relacionado_a','target':s} for s in entry['links']],
        'functions':[], 'sources':[source],'open_questions':['Conferir versão consolidada, alterações, vigência por dispositivo e efeitos diferidos.'] if not entry['source_verified'] else ['Conferir vigência material e efeitos diferidos; captura de texto integral ainda pendente.'],
        'provenance':{'status':'indice_documental','retrieved_at':None,'notes':entry['notes']},
        'completeness':{'classification':'referencia_catalogada','full_text':False,'article_count':0,'do_not_use_as_consolidated_law':True},
        'compatibility':{'cognoscere_okf_version':'0.1','document_type':'source','status':'review','contract':{'no_unverified_normative_conclusions':True}}}
    (parent/(entry['slug']+'.okf')).write_text(dumps(record),encoding='utf-8')
( ROOT/'catalogo_fontes.json').write_text(dumps({'date':DATE,'version':'0.1','status':'inventario_bibliografico_nao_compilacao_integral','acts':L}),encoding='utf-8')
manifest={'bundle':'legislacao-empresarial-br-bahia','schema':'okf.knowledge.v1','version':'0.1.0','as_of':DATE,'status':'catalogo_com_sync_pendente','normas_catalogadas':len(L),'urls_consultadas':sum(a['source_verified'] for a in L),'okfs_referencias':len(L),'okfs_tematicos':42,'fontes_integrais_baixadas':0,'artigos_indexados':0,'domains':dict(collections.Counter(a['domain'] for a in L)),'topics':TAXONOMY,'paths':{'catalog':'catalogo_fontes.json','legal_sources':'documentos_oficiais','okfs':'okf','ingest':'sync_official.py'},'caveats':['Esta distribuição inicial NÃO contém a íntegra dos atos, devido a impossibilidade de download direto neste ambiente.','Executar sync_official.py em computador com internet; validar relatório para determinar completude por diploma.','Não afirmar vigência de disposições individuais a partir de textos compilados sem conferência.','Leis municipais, convênios, portarias e regulamentações setoriais são abertos/variáveis; exigem recorte territorial e setorial.']}
(ROOT/'manifest.json').write_text(dumps(manifest),encoding='utf-8')
with (ROOT/'fontes.csv').open('w',newline='',encoding='utf-8') as h:
 w=csv.DictWriter(h,fieldnames=['id','domain','title','official_url','authority','source_verified','notes']);w.writeheader();w.writerows([{k:r.get(k) for k in w.fieldnames} for r in L])
print('Catalogadas',len(L),'fontes;',sum(a['source_verified'] for a in L),'URLs consultadas. OKF criados:',len(list((ROOT/'okf').rglob('*.okf'))))
