# OKF · Legislação Empresarial Brasil/Bahia — catálogo inicial e coletor

Data de referência do catálogo: **19 de outubro de 2026**.

## O que o ZIP contém efetivamente

- **86 fichas OKF** de fontes normativas/portais oficiais, com identificador, temas, origem, URL e lacunas de revisão.
- **42 OKFs temáticos** com estrutura de decisão e links para normas primárias: abertura JUCEB, registro, MEI, Simples Nacional (Anexos I–V, fator R, DAS, segregação, sublimites), ICMS-BA, ISS, IPI, PIS/Cofins, IRPJ/CSLL, obrigações eletrônicas e reforma IBS/CBS/IS.
- Um **catálogo bibliográfico** `catalogo_fontes.json` + `fontes.csv`.
- Um **coletor** `sync_official.py` que, em máquina com acesso à internet, **baixa os arquivos oficiais íntegros**, gera `documentos_oficiais/`, `textos_extraidos/` e `okf_compilados/` e grava hashes SHA-256.
- `audit_bundle.py` para checagem de referências, integridade e situação real da captura.

**Limitação material:** esta execução foi realizada em ambiente no qual conexões externas do Python não resolveram DNS. Portanto **nenhuma cópia integral de lei ou PDF foi baixada e incluída nesta distribuição inicial**. Os OKFs iniciais são registros de fonte e mapas temáticos, não transcrições integrais das leis. O coletor NÃO foi executado com acesso à internet. Não tratar o catálogo como legislação consolidada, muito menos como norma validada dispositivo a dispositivo.

## Comandos para produzir os documentos e os OKFs integrais no Linux

Extraia o ZIP em uma pasta de sua escolha, por exemplo `~/okf-legislacao-empresarial/`, e execute:

```bash
cd ~/okf-legislacao-empresarial
python -m venv .venv
source .venv/bin/activate
python -m pip install beautifulsoup4 pymupdf
python sync_official.py --verified-only
python audit_bundle.py
```

Os registros com `source_verified: true` tiveram o **endereço e a identificação conferidos em fontes web oficiais**, mas o texto completo **ainda não está no ZIP**. Para incluir URLs do catálogo cujo endereço exato ainda precisa ser verificado:

```bash
python sync_official.py --all
```

O relatório `relatorio_sincronizacao.json` discrimina **cada tentativa, falha HTTP, tamanho em bytes, hash SHA-256, contagem de caracteres e artigos extraídos**. Endereços de portais dinâmicos podem requerer seleção manual de PDFs ou atos específicos. Não considere uma URL como prova de importação bem-sucedida.

Para conferir uma fonte isolada, por exemplo a LC 123/2006:

```bash
python sync_official.py --ids BR.LC.123.2006
```

Para conferir a Lei ICMS da Bahia, o RICMS-BA e o Anexo I:

```bash
python sync_official.py --ids \
  BR.BA.LEI_BA.7014.1996 \
  BR.BA.DECRETO_BA.13780.2012 \
  BR.BA.ANEXO_RICMS_BA.1.2026
```

`--overwrite` permite atualização das cópias oficiais existentes. O coletor **não sobrescreve** nenhum ato remoto e só acessa hosts oficiais listados em seus filtros.

## Como os arquivos se organizam

```text
manifest.json                  estado e contagem inicial
catalogo_fontes.json           lista de fontes e links
fontes.csv                     auditoria bibliográfica
okf/                           86 OKFs de fonte inicial
okf_conceitos/                  42 OKFs temáticos de pesquisa
sync_official.py               download + extração + indexação
okf_compilados/                gerado após download: OKFs com texto de artigos
textos_extraidos/              gerado após download: textos integrais extraídos
documentos_oficiais/           gerado após download: HTML/PDF originais
relatorio_sincronizacao.json   gerado após download: resultados e falhas
audit_bundle.py                verificador da compilação
```

Os textos extraídos por PDF contêm marcadores de páginas; fragmentos por artigo são **candidatos automáticos** e podem incluir notas, repetição de artigos históricos ou cortes incorretos. O hash do arquivo oficial é guardado em cada OKF. O código nunca afirma que uma variante textual histórica corresponde automaticamente ao texto vigente.

## Compatibilidade com OKF / Cognoscere e Metis

Estrutura JSON válida com extensão `.okf`, contendo `schema: okf.knowledge.v1`, `title`, `summary`, `elements`, `properties`, `relations`, `functions`, `sources` e `open_questions`. Um campo adicional `compatibility` registra a correspondência com o perfil conceitual do Cognoscere OKF v0.1 (fonte ou skill). **Não se afirma que a memória neural Metis foi gerada**: a conversão para `safetensors` requer o importador e o endpoint Metis operacionais no ambiente do usuário, seguidos de verificação de compatibilidade.

## Limites do escopo: legislação de empresas não é conjunto fechado

- Registro público e procedimentos seguem a JUCEB e manuais DREI.
- ICMS depende de legislação estadual e convênios, protocolos, produtos, operações e período.
- ISS e licenciamento dependem do município; **não foram compilados os códigos tributários de todos os municípios baianos**.
- Setores (saúde, ensino, transportes, alimentos, construção, indústria, agro etc.) podem exigir normas específicas de conselhos, agências, vigilância sanitária, ambientais e trabalhistas.
- Resoluções e portarias podem surgir diariamente. Textos compilados podem ter dispositivos revogados e cláusulas com produção futura de efeitos.
- A JUCEB não legisla sobre impostos; integra registros com redes de legalização enquanto competências tributárias pertencem à União, ao Estado e aos Municípios.

**Uso jurídico:** conteúdo de pesquisa e indexação, sujeito à conferência do ato original, de sua vigência e de seus efeitos temporais. Para decisões empresariais concretas, confirmar a legislação no Diário Oficial correspondente e validar por profissional habilitado.

## Fontes oficiais prioritárias

- JUCEB: https://www.ba.gov.br/juceb/legislacao/leis
- DREI e manuais: https://www.gov.br/empresas-e-negocios/pt-br/drei/legislacao/instrucoes-normativas/instrucoes-normativas
- Simples / CGSN: https://normas.receita.fazenda.gov.br/sijut2consulta/consulta/normas.fazenda.gov.br/sijut2consulta/link.action?idAto=92278&visao=original
- LC 123: https://www.planalto.gov.br/ccivil_03/leis/lcp/lcp123.htm
- LC 214: https://www.planalto.gov.br/ccivil_03/leis/lcp/lcp214compilado.htm
- LC 227: https://www.planalto.gov.br/ccivil_03/leis/lcp/lcp227.htm
- Lei BA 7.014: https://mbusca.sefaz.ba.gov.br/DITRI/leis/leis_estaduais/legest_1996_7014_icmscomnotas.pdf
- RICMS BA: https://mbusca.sefaz.ba.gov.br/DITRI/normas_complementares/decretos/decreto_2012_13780_ricms_texto_2021.pdf

## Incremento necessário para um bundle juridicamente completo

1. Baixar, extrair e preservar cada fonte (script fornecido); verificar falhas.
2. Acompanhar anexos, versões consolidadas, alterações e ato originário no DOU/DOE.
3. Revisar fragmentos de artigos, alíneas, incisos, anexos e vigência temporal.
4. Adicionar legislação municipal do território definido e convênios/portarias aplicáveis aos CNAEs e NCMs da empresa.
5. Executar validação editorial/jurídica e compilação para memória Metis, sem confundir texto recuperado com parecer jurídico.
