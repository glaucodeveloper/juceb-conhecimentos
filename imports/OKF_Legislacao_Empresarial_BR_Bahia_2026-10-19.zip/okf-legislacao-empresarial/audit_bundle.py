#!/usr/bin/env python3
"""Checks structure, duplicate IDs, source provenance and fetch coverage."""
from pathlib import Path
import json,collections,sys
P=Path(__file__).parent
raw=json.loads((P/'catalogo_fontes.json').read_text(encoding='utf-8'))['acts']
source_ids=[a['id'] for a in raw]
errs=[]
if len(source_ids)!=len(set(source_ids)):errs.append('IDs normativos duplicados')
records=[]
for name in ('okf','okf_conceitos','okf_compilados'):
 for f in (P/name).rglob('*.okf') if (P/name).exists() else []:
  try:
   data=json.loads(f.read_text(encoding='utf-8'))
   if data.get('schema')!='okf.knowledge.v1':errs.append(f'{f}: schema inesperado')
   if not data.get('sources'):errs.append(f'{f}: sem fontes')
   if not data.get('id'):errs.append(f'{f}: sem id')
   if name=='okf_compilados':
    if not data.get('completeness',{}).get('full_source_bytes'):errs.append(f'{f}: status de fonte integral não sustentado')
    for src in data['sources']:
     for key in ('file','sha256'):
      if not src.get(key):errs.append(f'{f}: {key} ausente')
   records.append((name,data['id'],f))
  except Exception as e:errs.append(f'{f}: {e}')
if len({d[1] for d in records if d[0]=='okf'})!=len(raw): errs.append('Catalogo vs OKFs de normas divergentes')
for name,id,f in records:
 if name=='okf_conceitos':
  for rel in json.loads(f.read_text())['relations']:
   if rel['type']=='fundamentado_em' and rel['target'] not in source_ids:errs.append(f'{f}: ref inexistente {rel["target"]}')
statuses=collections.Counter(a['domain'] for a in raw)
print('CATALOGO:',len(raw),'fontes; URL consultada:',sum(a['source_verified'] for a in raw))
print('OKF REFERENCIA:',sum(n=='okf' for n,i,f in records),' | OKF CONCEITOS:',sum(n=='okf_conceitos' for n,i,f in records),' | OKF TEXTO CAPTURADO:',sum(n=='okf_compilados' for n,i,f in records))
for k,n in sorted(statuses.items()): print(f'  {k}: {n}')
print('ERROS:',len(errs))
for e in errs:print(' -',e)
sys.exit(bool(errs))
