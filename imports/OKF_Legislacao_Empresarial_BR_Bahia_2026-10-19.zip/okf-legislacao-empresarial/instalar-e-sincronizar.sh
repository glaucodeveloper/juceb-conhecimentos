#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python sync_official.py --verified-only "$@"
python audit_bundle.py
printf '\nArquivos baixados em documentos_oficiais/; textos em textos_extraidos/; OKFs em okf_compilados/.\n'
